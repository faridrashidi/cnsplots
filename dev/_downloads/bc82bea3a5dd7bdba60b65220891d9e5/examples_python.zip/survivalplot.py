"""
Survival Analysis
-----------------

Create Kaplan-Meier survival curves and cumulative incidence plots.

Survival plots are essential for time-to-event analysis in clinical and
biological research. cnsplots provides automatic omnibus log-rank testing and
optional, explicitly selected pairwise hazard-ratio inference.
"""

# %%
# Load data
# ~~~~~~~~~
import lifelines as ll
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

import cnsplots as cns

waltons = ll.datasets.load_waltons()


# %%
# Basic survival plot (two groups)
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Kaplan-Meier survival curves with automatic log-rank test.
cns.figure(150, 150)
cns.survivalplot(
    data=waltons,
    duration="T",
    event="E",
    hue="group",
    hue_order=["miR-137", "control"],
    show_hazard_ratio=False,
)
_ = plt.legend(loc="upper right")
plt.title("Kaplan-Meier Survival Curves")


# %%
# Confidence bands and median survival
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Combine pointwise confidence bands with median-survival guides. The annotation
# reports a group's median as ``not reached`` when its curve never falls to 0.5.
cns.figure(150, 160)
ax = cns.survivalplot(
    data=waltons,
    duration="T",
    event="E",
    hue="group",
    hue_order=["miR-137", "control"],
    ci_show=True,
    show_median_survival=True,
    show_hazard_ratio=False,
    pvalue_loc="upper right",
)
ax.set_xlabel("Time")
_ = ax.legend(loc="lower left")
plt.title("Confidence Bands and Median Survival")


# %%
# Landmark analysis with a risk table
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Mark 36 time units, report each group's survival probability there, and run
# the two-group fixed-time comparison. The same ticks are used by the risk table.
cns.figure(170, 170)
ax = cns.survivalplot(
    data=waltons,
    duration="T",
    event="E",
    hue="group",
    hue_order=["miR-137", "control"],
    landmark_time=36,
    show_risk_table=True,
    risk_table_ypos=-0.25,
    xticks=np.arange(0, 61, 12),
    show_hazard_ratio=False,
    pvalue_loc="upper right",
)
ax.set_xlabel("Time")
_ = ax.legend(loc="lower left")
plt.title("36-Unit Landmark with Risk Table")


# %%
# Landmark survival and RMST
# ~~~~~~~~~~~~~~~~~~~~~~~~~~
# Use a shared horizon to compare survival probability at 48 time units and the
# area under each survival curve through that time. A single dashed guide marks
# the common landmark and RMST truncation time.
cns.figure(150, 170)
ax = cns.survivalplot(
    data=waltons,
    duration="T",
    event="E",
    hue="group",
    hue_order=["miR-137", "control"],
    landmark_time=48,
    rmst_time=48,
    show_hazard_ratio=False,
    pvalue_loc="upper right",
)
ax.set_xlabel("Time")
_ = ax.legend(loc="lower left")
plt.title("48-Unit Survival and RMST")


# %%
# Survival plot with legend outside
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Move legend to avoid overlapping curves.
cns.figure(150, 180)
cns.survivalplot(
    data=waltons, duration="T", event="E", hue="group", hue_order=["miR-137", "control"]
)
cns.take_legend_out()
plt.title("Survival with External Legend")


# %%
# Cumulative incidence plot
# ~~~~~~~~~~~~~~~~~~~~~~~~~
# Show cumulative incidence instead of survival probability.
cns.figure(150, 150)
ax = cns.cumulativeincidenceplot(
    data=waltons,
    duration="T",
    event="E",
    hue="group",
    hue_order=["miR-137", "control"],
    xticks=np.arange(0, waltons["T"].max() + 2, 12),
    show_risk_table=True,
    risk_table_ypos=-0.2,
    pvalue_loc="lower right",
)
ax.set_xlabel("Time (Months)")
_ = plt.legend(loc="upper left")
plt.title("Cumulative Incidence")


# %%
# Cumulative incidence without risk table
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Cleaner plot without the risk table.
cns.figure(150, 150)
ax = cns.cumulativeincidenceplot(
    data=waltons,
    duration="T",
    event="E",
    hue="group",
    hue_order=["miR-137", "control"],
    show_risk_table=False,
    pvalue_loc="lower right",
)
ax.set_xlabel("Time (Months)")
_ = plt.legend(loc="upper left")
plt.title("Cumulative Incidence (No Risk Table)")


# %%
# Survival plot with custom colors
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Use different color palettes.
cns.figure(150, 150, "BlueRed")
cns.survivalplot(data=waltons, duration="T", event="E", hue="group")
cns.take_legend_out()
plt.title("BlueRed Palette")


# %%
# Simulated clinical trial data (multiple groups)
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Create synthetic data with multiple treatment groups.
np.random.seed(42)
n_patients = 150

# Simulate different survival characteristics for each group
survival_data = []

# Control group - baseline survival
control_times = np.random.exponential(scale=24, size=n_patients // 3)
control_events = np.random.binomial(1, 0.7, n_patients // 3)
for t, e in zip(control_times, control_events):
    survival_data.append({"time": t, "event": e, "group": "Control"})

# Treatment A - moderate improvement
treatment_a_times = np.random.exponential(scale=36, size=n_patients // 3)
treatment_a_events = np.random.binomial(1, 0.6, n_patients // 3)
for t, e in zip(treatment_a_times, treatment_a_events):
    survival_data.append({"time": t, "event": e, "group": "Treatment A"})

# Treatment B - strong improvement
treatment_b_times = np.random.exponential(scale=48, size=n_patients // 3)
treatment_b_events = np.random.binomial(1, 0.5, n_patients // 3)
for t, e in zip(treatment_b_times, treatment_b_events):
    survival_data.append({"time": t, "event": e, "group": "Treatment B"})

clinical_df = pd.DataFrame(survival_data)


# %%
# Survival plot with three groups
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Compare multiple treatment arms with an omnibus test and two Cox contrasts.
# Pair tuples are (reference, comparison). Holm correction covers both requested
# contrasts; the omnibus test is separate and HR confidence intervals remain 95%.
cns.figure(260, 240)
ax = cns.survivalplot(
    data=clinical_df,
    duration="time",
    event="event",
    hue="group",
    hue_order=["Control", "Treatment A", "Treatment B"],
    pairs=[("Control", "Treatment A"), ("Control", "Treatment B")],
    p_adjust="holm",
    pvalue_loc="upper right",
)
ax.set_xlabel("Time (Months)")
cns.take_legend_out()
plt.title("Three-Arm Clinical Trial")

# Retrieve the statistics used in the annotation without refitting any models.
# ``estimate`` is the comparison-versus-reference hazard ratio for these rows.
results = cns.get_survival_results(ax)
contrasts = results.loc[results["kind"] == "pairwise_cox"]
print(
    contrasts[
        ["group1", "group2", "estimate", "pvalue_raw", "pvalue_adjusted", "status"]
    ].to_string(index=False)
)


# %%
# Cumulative incidence with three groups
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Show cumulative events for multiple groups.
cns.figure(150, 180)
ax = cns.cumulativeincidenceplot(
    data=clinical_df,
    duration="time",
    event="event",
    hue="group",
    hue_order=["Control", "Treatment A", "Treatment B"],
    show_risk_table=True,
    risk_table_ypos=-0.25,
    pvalue_loc="upper left",
)
ax.set_xlabel("Time (Months)")
cns.take_legend_out()
plt.title("Cumulative Incidence - Three Arms")


# %%
# Side-by-side survival comparisons
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Compare survival vs cumulative incidence.
mp = cns.multipanel(max_width=450)

mp.panel("A", 160, 120)
cns.survivalplot(
    data=waltons,
    duration="T",
    event="E",
    hue="group",
)
mp.get_axes("A").legend().remove()
mp.get_axes("A").set_title("Survival Probability")

mp.panel("B", 160, 120)
cns.cumulativeincidenceplot(
    data=waltons,
    duration="T",
    event="E",
    hue="group",
    show_risk_table=False,
    pvalue_loc="center",
)
mp.get_axes("B").legend().remove()
mp.get_axes("B").set_title("Cumulative Incidence")


# %%
# Survival with biomarker stratification
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Stratify patients by biomarker expression.
np.random.seed(123)
n = 200

# Simulate biomarker data
biomarker_data = []
for _ in range(n // 2):
    # Low expression - worse survival
    time = np.random.exponential(scale=20)
    event = np.random.binomial(1, 0.8)
    biomarker_data.append({"time": time, "event": event, "biomarker": "Low"})

for _ in range(n // 2):
    # High expression - better survival
    time = np.random.exponential(scale=40)
    event = np.random.binomial(1, 0.5)
    biomarker_data.append({"time": time, "event": event, "biomarker": "High"})

biomarker_df = pd.DataFrame(biomarker_data)

cns.figure(150, 150)
ax = cns.survivalplot(
    data=biomarker_df,
    duration="time",
    event="event",
    hue="biomarker",
    hue_order=["High", "Low"],
    pvalue_loc="upper right",
)
ax.set_xlabel("Time (Months)")
cns.take_legend_out()
plt.title("Survival by Biomarker Expression")


# %%
# Cumulative incidence with custom x-axis ticks
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Control the time axis display.
cns.figure(150, 180)
ax = cns.cumulativeincidenceplot(
    data=waltons,
    duration="T",
    event="E",
    hue="group",
    hue_order=["miR-137", "control"],
    xticks=np.arange(0, 80, 10),
    show_risk_table=True,
    risk_table_ypos=-0.2,
    pvalue_loc="lower right",
)
ax.set_xlabel("Time (Months)")
_ = plt.legend(loc="upper left")
plt.title("Custom X-Axis Ticks")


# %%
# Survival analysis with censoring visualization
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# The curves automatically handle censored observations (shown as vertical marks).
cns.figure(150, 150)
ax = cns.survivalplot(
    data=clinical_df,
    duration="time",
    event="event",
    hue="group",
    hue_order=["Control", "Treatment B"],
)
ax.set_xlabel("Time (Months)")
_ = plt.legend(loc="upper right")
plt.title("Survival with Censoring Marks")
