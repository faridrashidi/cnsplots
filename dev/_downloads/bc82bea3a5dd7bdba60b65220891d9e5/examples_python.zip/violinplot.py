"""
Violin Plot
-----------

Create violin plots showing distribution shapes with optional statistical testing.

Violin plots combine box plots with kernel density estimation to show
the full distribution shape, making them ideal for comparing distributions
across categories.
"""

# %%
# Load data
# ~~~~~~~~~

import cnsplots as cns

tips = cns.datasets.load_dataset("tips")
iris = cns.datasets.load_dataset("iris")


# %%
# Basic violin plot
# ~~~~~~~~~~~~~~~~~
# Simple violin plot with embedded box plot (default).
cns.figure(100, 150)
ax = cns.violinplot(data=tips, x="day", y="total_bill")
ax.set_title("Basic Violin Plot")


# %%
# Violin plot with statistical testing
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Use ``pairs="all"`` with Holm correction for all Mann-Whitney U tests.
cns.figure(100, 150, "Tableau")
ax = cns.violinplot(
    data=tips,
    x="day",
    y="total_bill",
    pairs="all",
    test="Mann-Whitney",
    p_adjust="holm",
)
ax.set_title("Holm-Corrected Pairwise Comparisons")


# %%
# Violin plot with specific pair comparisons
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Test selected pairs with Welch's t-test and Benjamini-Hochberg correction.
cns.figure(100, 150)
ax = cns.violinplot(
    data=iris,
    x="species",
    y="sepal_length",
    pairs=[("setosa", "versicolor"), ("setosa", "virginica")],
    test="t-test_welch",
    p_adjust="fdr_bh",
)
ax.set_title("Welch Tests with FDR Correction")


# %%
# Violin plot without embedded box plot
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Set ``add_box=False`` for cleaner violin shapes.
cns.figure(100, 150)
ax = cns.violinplot(data=tips, x="day", y="total_bill", add_box=False)
ax.set_title("Violin Plot without Box")


# %%
# Violin plot with custom width
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Adjust violin body width with the ``width`` parameter.
mp = cns.multipanel(max_width=330)

mp.panel("A", 120, 80)
cns.violinplot(data=tips, x="day", y="total_bill", width=0.4)
mp.get_axes("A").set_title("width=0.4 (narrow)")

mp.panel("B", 120, 80, margin_right=0)
cns.violinplot(data=tips, x="day", y="total_bill", width=0.9)
mp.get_axes("B").set_title("width=0.9 (wide)")


# %%
# Grouped violin plot with hue
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Use ``hue`` for side-by-side violins within each category. Embedded boxes stay
# white by default and can be colored independently with ``box_color``.
cns.figure(180, 120)
ax = cns.violinplot(
    data=tips,
    x="day",
    y="total_bill",
    hue="sex",
    box_color="white",
)
cns.take_legend_out()
ax.set_title("Grouped Violin Plot")


# %%
# Split violin plot
# ~~~~~~~~~~~~~~~~~
# Use ``split=True`` to show two hue levels as halves of the same violin.
# This is useful for direct comparison of two groups.
cns.figure(100, 150)
ax = cns.violinplot(
    data=tips,
    x="day",
    y="total_bill",
    hue="sex",
    split=True,
    add_box=False,
)
cns.take_legend_out()
ax.set_title("Split Violin Plot")


# %%
# Violin plot with different inner representations
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# The ``inner`` parameter controls what's shown inside the violin.
# Options: "box" (default), "quart", "point", "stick", None
mp = cns.multipanel(max_width=450)

mp.panel("A", 110, 80)
cns.violinplot(data=tips, x="day", y="total_bill", inner="quart", add_box=False)
mp.get_axes("A").set_title("inner='quart'")

mp.panel("B", 110, 80)
cns.violinplot(data=tips, x="day", y="total_bill", inner="point", add_box=False)
mp.get_axes("B").set_title("inner='point'")

mp.panel("C", 110, 80)
cns.violinplot(data=tips, x="day", y="total_bill", inner="stick", add_box=False)
mp.get_axes("C").set_title("inner='stick'")


# %%
# Horizontal violin plot
# ~~~~~~~~~~~~~~~~~~~~~~
# Swap x and y for horizontal orientation.
cns.figure(150, 100)
ax = cns.violinplot(
    data=iris,
    x="sepal_width",
    y="species",
    order=["virginica", "versicolor", "setosa"],
)
ax.set_title("Horizontal Violin Plot")


# %%
# Violin plot with custom palette
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Use built-in palettes or custom colors.
cns.figure(100, 150, "Bold")
ax = cns.violinplot(data=tips, x="day", y="total_bill")
ax.set_title("Bold Palette")


# %%
# Violin plot comparing multiple measurements
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Melt data to compare distributions across variables.
iris_melted = iris.melt(
    id_vars=["species"],
    value_vars=["sepal_length", "sepal_width", "petal_length", "petal_width"],
    var_name="measurement",
    value_name="value",
)

cns.figure(120, 120, "Set2")
ax = cns.violinplot(
    data=iris_melted[iris_melted["species"] == "setosa"],
    x="measurement",
    y="value",
)
ax.set_xticklabels(
    ax.get_xticklabels(), rotation=45, ha="right", rotation_mode="anchor"
)
ax.set_title("Setosa Measurements Distribution")


# %%
# Violin plot with grouped comparisons
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Statistical testing across hue groups.
cns.figure(150, 120)
ax = cns.violinplot(
    data=tips,
    x="day",
    y="total_bill",
    hue="smoker",
    pairs=[(("Sat", "Yes"), ("Sat", "No"))],
    add_box=False,
)
cns.take_legend_out()
ax.set_title("Grouped Violin with Statistical Testing")
